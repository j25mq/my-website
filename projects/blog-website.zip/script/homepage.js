function switchMode() {
        const element = document.body;
        element.classList.toggle("dm");
    }
